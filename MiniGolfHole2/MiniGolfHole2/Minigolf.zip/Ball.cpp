#include "Ball.h"
#include "Entity.h"
#include "glm/gtc/matrix_transform.hpp"

#include <iostream>

#include <vector>
using namespace std;

Ball::Ball(void)
{
	hasGravity = true;


	//Create ball
	const double PI = 3.1415926535897;
	//Initial triangle number factor
	const float space = 20;
	//Scale
	radius = 0.1;

	vector <float> vertices = vector<float>();
	for(double b=0;b<=180-space;b+=space)
	{
		for(double a = 0; a <= 360-space; a+=space)
		{
			vertices.push_back(radius * sin((a) / 180 * PI) * sin((b) / 180 * PI));
			vertices.push_back(radius * cos((a) / 180 * PI) * sin((b) / 180 * PI));
			vertices.push_back(radius * cos((b) / 180 * PI));

			vertices.push_back(radius * sin((a) / 180 * PI) * sin((b+space) / 180 * PI));
			vertices.push_back(radius * cos((a) / 180 * PI) * sin((b+space) / 180 * PI));
			vertices.push_back(radius * cos((b+space) / 180 * PI));

			vertices.push_back(radius * sin((a+space) / 180 * PI) * sin((b) / 180 * PI));
			vertices.push_back(radius * cos((a+space) / 180 * PI) * sin((b) / 180 * PI));
			vertices.push_back(radius * cos((b) / 180 * PI));

			vertices.push_back(radius * sin((a+space) / 180 * PI) * sin((b) / 180 * PI));
			vertices.push_back(radius * cos((a+space) / 180 * PI) * sin((b) / 180 * PI));
			vertices.push_back(radius * cos((b) / 180 * PI));

			vertices.push_back(radius * sin((a+space) / 180 * PI) * sin((b+space) / 180 * PI));
			vertices.push_back(radius * cos((a+space) / 180 * PI) * sin((b+space) / 180 * PI));
			vertices.push_back(radius * cos((b+space) / 180 * PI));

			vertices.push_back(radius * sin((a) / 180 * PI) * sin((b+space) / 180 * PI));
			vertices.push_back(radius * cos((a) / 180 * PI) * sin((b+space) / 180 * PI));
			vertices.push_back(radius * cos((b+space) / 180 * PI));
		}
	}
	setVerts(vertices);
}


Ball::~Ball(void)
{
}


void Ball::Update()
{

	//Update super class
	Entity::Update();
}



