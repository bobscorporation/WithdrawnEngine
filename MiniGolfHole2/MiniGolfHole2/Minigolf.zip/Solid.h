#pragma once

//Solids are objects that will not react to a collision, but Entities can collide with them
//Will not collide with Solids
class Solid
{
public:
	Solid(void);
	~Solid(void);

};

