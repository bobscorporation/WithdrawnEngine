#include "Entity.h"
#include "Level.h"
#include "glm/gtc/matrix_transform.hpp"
#include <iostream>

using namespace std;

const double PI = 3.14159265358;
const double Gravity = -0.002;

Entity::Entity(void)
{
	Level::Instance().getRefEntityList().push_back(this);

	transformMatrix = glm::mat4(1,0,0,0,
								0,1,0,0,
								0,0,1,0,
								0,0,0,1);

	id = Level::Instance().getRefEntityList().size();
	hasGravity = false;
	mass = 0;
	bounceDampening = 0.3f;
}


Entity::~Entity(void)
{
}

void Entity::setVerts(std::vector < float > teeVerts)
{
	vertices = teeVerts;
}

vector < float > Entity::getVerts(void)
{
	return vertices;
}

//Updates this entity
void Entity::Update()
{
	if (hasGravity)
		ApplyForce(0,Gravity,0);

	//Apply all forces since last tick
	acceleration = lastTickForces;
	lastTickForces = glm::vec3(0);

	//Check for a collision given current force. If so, PhysicalCollision will handle the next tick's movement
	glm::vec3 intPos, intNorm, nextVel;
	nextVel = velocity+acceleration;
	radius = 0;
	if (RayIntersection(intPos, intNorm, position, nextVel+glm::normalize(nextVel)*radius) > -2)
	{
		/*velocity = */PhysicalCollision(intPos, intNorm, position,nextVel+glm::normalize(nextVel)*radius,0);
		velocity += acceleration;
		//position += velocity;
	}
	else
	{
		velocity += acceleration;
		position += velocity;
		
	}


	transformMatrix = glm::translate(glm::mat4(), position);
}


//Casts a ray from rayPos and fills intersectPos and intersectNormal if there was an intersection given the magnitude and direction of rayDirec
//Return -2 = no intersection
//Return -1 = intersection with solid
//Return 0-n = intersection with Entity. Entity ID is returned
int Entity::RayIntersection(glm::vec3 &intersectPos, glm::vec3 &intersectNormal, glm::vec3 rayPos, glm::vec3 rayDirec)
{
	//Loop through all tiles

	//Reference the list of vertices rather than copy them by accessing constantly
	std::vector<float> &tileVerts = (Level::Instance().getRefOrderedTileVerts());
	std::vector<float> &tileNorms = (Level::Instance().getRefTileNorms());
	int vertsSize = tileVerts.size()/9;
	for(int i=0;i<vertsSize;i++)
	{
		//Extend the triangle to a plane
		//Ax + By + Cz + D = 0
		//D is the dot product of a point on the plane and the nmal to the plane
		glm::vec3 planeNormal;
		float planeD;
		planeNormal.x = tileNorms[i*9];
		planeNormal.y = tileNorms[i*9+1];
		planeNormal.z = tileNorms[i*9+2];
		planeD = -glm::dot(glm::vec3(tileVerts[i*9], tileVerts[i*9+1], tileVerts[i*9+2]),
									glm::vec3(planeNormal.x,planeNormal.y,planeNormal.z));
		

		//Find out if the ray crossed the plane
		enum Loc {PlaneFront, PlaneBack, OnPlane};
		Loc pStartLoc, pEndLoc;
		float p;

		p = glm::dot(planeNormal,rayPos) + planeD;
		if (p > 0)
			pStartLoc = PlaneFront;
		else if (p < 0)
			pStartLoc = PlaneBack;
		else
			pStartLoc = OnPlane;

		p = glm::dot(planeNormal,rayPos + rayDirec) + planeD;
		if (p > 0)
			pEndLoc = PlaneFront;
		else if (p < 0)
			pEndLoc = PlaneBack;
		else
			pEndLoc = OnPlane;

		//No collision with this triangle
		if (pStartLoc == pEndLoc)
			continue;

		//Find the point of collision
		float t;
		glm::vec3 intersect;
		t = - (glm::dot(planeNormal, rayPos) + planeD) / glm::dot(planeNormal, glm::normalize(rayDirec));
		intersect = rayPos + glm::normalize(rayDirec)*t;

		//Determine if collision point is on the triangle
		//If the sum of all angles to the triangles vertices is 360, it is on the triangle
		glm::vec3 vt1,vt2,vt3,v1,v2,v3;
		float thetaSum;
		vt1 = glm::vec3(tileVerts[i*9],tileVerts[i*9+1],tileVerts[i*9+2]);
		vt2 = glm::vec3(tileVerts[i*9+3],tileVerts[i*9+4],tileVerts[i*9+5]);
		vt3 = glm::vec3(tileVerts[i*9+6],tileVerts[i*9+7],tileVerts[i*9+8]);

		v1 = glm::normalize(intersect - vt1);
		v2 = glm::normalize(intersect - vt2);
		v3 = glm::normalize(intersect - vt3);
		thetaSum = acos(glm::dot(v1,v2)) + acos(glm::dot(v2,v3)) + acos(glm::dot(v3,v1));

		if (std::fabs(thetaSum - (2 * PI)) < 0.1)
		{
			intersectPos = intersect;
			intersectNormal = planeNormal;
			return -1;
		}
	}
	return -2;

}

//Does a collision based on given information
//Returns the new velocity
glm::vec3 Entity::PhysicalCollision(glm::vec3 intersectPos, glm::vec3 intersectNormal, glm::vec3 rayPos, glm::vec3 rayDirec, int entityId)
{
	glm::vec3 nRayDirec = glm::normalize(rayDirec);	
	glm::vec3 nIntersectNormal = glm::normalize(intersectNormal);
	float bounceScalar = glm::length(rayDirec) - glm::length((intersectPos - rayPos));
	//cout << "intersect - raypos " << glm::length(intersectPos - rayPos) << '\n';
	//cout << "rayDirec " << glm::length(rayDirec) << '\n';

	glm::vec3 reflectVector = glm::normalize(-2*glm::dot(nRayDirec,nIntersectNormal)*nIntersectNormal+nRayDirec);
	
	//Set position to just before the intersection position
	position = (intersectPos + nIntersectNormal*0.002f);//*radius*0.01f*/);

	//cout << "newVel " << glm::length(newVel) << '\n';

	
	

	glm::vec3 newVel = reflectVector * ((glm::length(rayDirec)-radius));
	newVel -= newVel*glm::normalize(nIntersectNormal+glm::vec3(0.1,0.1,0.1))*bounceDampening;

	acceleration += newVel-velocity;

	//Check if new position will collide
	/*if (RayIntersection(intersectPos, intersectNormal, position, reflectVector * (bounceScalar+radius)) > -2)
	{
		cout << "---------------------RECURSION\n";
		PhysicalCollision(intersectPos, intersectNormal, position, reflectVector * (bounceScalar+radius), 0);
	}*/

	//Move to the reflected position
	position += reflectVector * (bounceScalar+radius);
	
	/*cout <<  "velocity " << velocity.y << '\n';
	cout <<  "newVel " << newVel.y << '\n';
	cout <<  "acceleration " << acceleration.y << '\n';
	cout <<  "finaly " << (velocity+acceleration).y << '\n';
	cout <<  "bounceScalar " << (bounceScalar) << '\n';
	cout <<  "reflectVector " << (reflectVector).y << '\n';*/
	
	return newVel;
}


void Entity::ApplyForce(float x, float y, float z)
{
	lastTickForces += glm::vec3(x,y,z);
}