#ifndef _FILEINPUT_H_
#define _FILEINPUT_H_
#pragma once
class FileInput
{
public:
	FileInput(void);
	~FileInput(void);
	void readFile(void);
};
#endif