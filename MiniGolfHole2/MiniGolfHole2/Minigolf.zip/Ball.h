#pragma once

#include "Entity.h"
#include "glm/glm.hpp"
#include <vector>

class Ball: public Entity
{
private:

public:
	Ball(void);
	~Ball(void);
	void Update();


};