#include "Solid.h"


Solid::Solid(void)
{
}


Solid::~Solid(void)
{
}
