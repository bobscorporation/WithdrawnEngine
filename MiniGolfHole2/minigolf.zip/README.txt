README

Dependencies:
glew32.lib
opengl32.lib

Instructions to run:
Open up project in Microsoft Visual Studio and press the 'play' button to
build the projct. After a successful build, the project will run, reading
in the couse.db file. To switch between holes, press the 'n' key to go to
the next hole, and the 'p' key to go to the previous hole.

Player 1 controls:
	w/s - Raise/lower the club's hit trajectory
	a/d - Move club's hit trajectory side to side
	Space - Hit the ball

Player 2 controls:
	'1' will spawn balls on the map
	
't' will toggle between top view and main view